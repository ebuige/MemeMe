//
//  MemeStruct.swift
//  MemeMe
//
//  Created by Troutslayer33 on 5/10/15.
//  Copyright (c) 2015 Troutslayer33. All rights reserved.
//

import UIKit
struct Meme {
    var textFieldTop: String?
    var textFieldBottom: String?
    var image: UIImage
    var memeImage: UIImage}
