//
//  MemeTextFieldDelegate.swift
//  MemeMe
//
//  Created by Troutslayer33 on 5/10/15.
//  Copyright (c) 2015 Troutslayer33. All rights reserved.
//

import Foundation
import UIKit

class MemeTextFieldDelegate: NSObject, UITextFieldDelegate {
    
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        
        //    var newText = textField.text as NSString
        //   newText = newText.stringByReplacingCharactersInRange(range, withString: string)
        let newText = (textField.text as NSString).stringByReplacingCharactersInRange(range, withString: string)
        textField.text = newText.uppercaseString
        return false
    }
    
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        if (textField.text == "BOTTOM" || textField.text == "TOP") {
            textField.text = nil
        }
        return true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        return true;
    }
}

